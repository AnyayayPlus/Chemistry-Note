# 架构与接口

## 运行边界

```mermaid
flowchart LR
  P["插件仓库"] -->|发布包| S["读者正在浏览的 VitePress 文章"]
  S -->|读源码、提交草稿| A["同源投稿 API"]
  A -->|GitHub App 安装令牌| R["该站点的内容仓库"]
  R -->|维护者合并后构建| S
```

首版使用一个 TypeScript 包。站长通过以下入口接入。

| 入口 | 运行位置 | 职责 |
| --- | --- | --- |
| `/vitepress` | 站点构建进程 | `withInlineEditor` 链接现有配置，为可编辑页面加入仓库相对路径、构建提交和 API 地址。 |
| `/vue` | 站点主题 | `<InlineEditor />` 提供编辑按钮、页内工作区、草稿和提交状态。点击编辑后才加载 Milkdown，首次进入源码视图再加载 CodeMirror。 |
| `/server` | Node 24 服务或 Node 兼容的函数 | `createEditorHandler` 用 Web Request/Response 接口读取原文、验证稿件，并以站长安装的 GitHub App 创建 PR。服务端模块通过单独入口导出。 |

包内使用 `src/vitepress/`、`src/vue/` 和 `src/server/` 对应这三个入口，`src/markdown/` 放浏览器与服务端共用的源码范围和保护规则。`playground/` 是插件仓库内的最小宿主站，带真实 Markdown 样例。同一份 npm tarball 可用于两个独立宿主。包还提供命令 vitepress-editor-api，用于启动同源 API 服务。

## 站长接入

以示例站为例，VitePress 项目根目录为 `playground/`，以下配置放在 `playground/.vitepress/config.mts`，首篇可编辑文章为仓库中的 `playground/docs/guide.md`。

```ts
import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vitepress'
import { withInlineEditor } from 'vitepress-inline-editor/vitepress'

export default withInlineEditor(defineConfig({ srcDir: 'docs' }), {
  repoRoot: fileURLToPath(new URL('../../', import.meta.url)),
  include: ['playground/docs/guide.md'],
  apiBase: '/api/editor/',
})
```

主题在 `doc-before` 插槽内挂载来自 `/vue` 的 `<InlineEditor />`。默认主题适配器在正文栏内切换阅读和编辑视图，关闭后恢复触发位置与焦点。自定义主题可显式指定正文容器。构建适配器串接宿主已有的 `transformPageData`，把 `page.filePath` 按 `srcDir`、`repoRoot` 换算成真实源路径。从 Git HEAD 取得提交 SHA，CI 也可显式传入 `revision`。路由重写、中文 URL 与部署前缀由此与源码路径解耦。虚拟页、生成页和找不到确定源文件的页面默认使用阅读视图。[VitePress 页面数据](https://vitepress.dev/reference/runtime-api#usedata) · [主题插槽](https://vitepress.dev/guide/extending-default-theme#layout-slots)

站长将 `createEditorHandler(options)` 返回的 `(request: Request) => Promise<Response>` 接到 `/api/editor/`。示例中的环境变量只在服务进程读取。目标仓库、分支和可写路径由此确定。

```ts
import { createEditorHandler } from 'vitepress-inline-editor/server'

export const handle = createEditorHandler({
  repository: process.env.CONTENT_REPOSITORY!,
  branch: 'main',
  include: ['playground/docs/guide.md'],
  origin: process.env.SITE_ORIGIN!,
  sessionSecret: process.env.EDITOR_SESSION_SECRET!,
  githubApp: {
    appId: process.env.GITHUB_APP_ID!,
    installationId: process.env.GITHUB_INSTALLATION_ID,
    privateKey: process.env.GITHUB_APP_PRIVATE_KEY!,
  },
})
```

处理器启动时验证必需配置。Chemistry-Note 接入时将目标设为自己的内容仓库和 `master` 分支，调整文章范围。纯静态宿主可以通过反向代理把同源路径转给单独运行的服务。

## 一份源码草稿，三种视图

编辑器提交原始 Markdown 作为文件内容。草稿记录源路径、基准 commit、文件的 Git blob SHA、当前文本和待提交编号。文本改变时写入 `localStorage`，切换视图前保存，按站点、仓库、分支和路径隔离。恢复草稿时带回原基准，发现远端版本不同就展示差异。本地存储不可用时保留内存中的文本并提示读者复制草稿。

1. **打开文章。** 从基准提交读取完整原文。单独保留 YAML 文件头，解析正文块和可编辑文字的源码范围。偏移统一使用 JavaScript 字符串的 UTF-16 单位，保留 BOM、原始换行和末尾空行。预览可标准化换行，写回时使用原文坐标。
2. **原位编辑。** 一份 Milkdown 文档承载全部正文，包括引用、列表和表格。底部工具栏对当前选区执行 ProseMirror 命令。适配器保存每个顶层节点在原稿中的范围，沿用未改节点的原始字节，按变更节点的序列化差异回写原稿。GFM 表格复用 Milkdown 的表格命令，HTML 表格按单元格的源码位置写回文字，并保留合并属性。
3. **源码与分屏。** 两种视图使用同一个 CodeMirror 文档，分屏多一个按草稿即时更新的预览栏。切换前结束当前编辑并合入草稿，中文输入法组合输入期间等到 `compositionend`。仅切换视图或进入后退出不会触发 Markdown 重新导出。
4. **显示站点语法。** 浏览器使用可在客户端运行的 Markdown 规则。普通图片按源文章目录解析，静态资源使用宿主提供的构建资源映射或只读 URL。预览地址与写入 Markdown 的原始路径分开保管。Chemistry-Note 在站点适配层接 MathJax、mhchem、提示框和徽章。未知 HTML 块显示其受保护的源码。站点脚本不在编辑预览中执行。[MathJax mhchem](https://docs.mathjax.org/en/v3.2/input/tex/extensions/mhchem.html)

## 投稿 HTTP 契约

站点可按用户偏好挂载编辑器。Chemistry-Note 的「设置 → 站内编辑」默认关闭。在该站，服务端先按投稿分支私下登记署名，然后创建 PR。社区服务核实 GitHub 已合并到目标分支、该文件确实有改动，再为首页和文件提供公开用户名及投稿次数。

| 请求 | 输入 | 成功响应 |
| --- | --- | --- |
| `GET /api/editor/source` | 查询参数 `path`、`revision`，取自页面的构建元数据。 | `200`，返回 `path`、`baseCommit`、`baseBlob`、`markdown`、仓库、分支和署名要求 `requiresContributor`。 |
| `POST /api/editor/submissions` | JSON 字段 `submissionId`、`path`、`baseCommit`、`baseBlob`、`markdown`。文本为完整单文件草稿。服务要求署名时，另传 `contributor: { name, email }`，缺失或无效返回 `422`。 | 首次创建返回 `201`，重试找回返回 `200`，均含 PR 编号、URL 和状态。没有文本变化时返回 `200 unchanged`。 |

浏览器在首次点击提交时生成随机 `submissionId`，把它和本次文本快照一起保存。网络失败可用相同编号重试，修改稿件后重新送审则分配新编号。读取须匹配服务端的文章范围，修订须属于配置的目标分支历史。提交只接受已支持的安全 Markdown 改动，改变受保护片段或新增可执行模板返回 `422` 并提示保留这些受保护源码。匿名投稿使用站点签名会话，校验请求来源并限频。站点可用自己的身份验证替换匿名策略。GitHub 安装令牌和私钥只存在服务端。[安装身份](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/authenticating-as-a-github-app-installation)

## 一个草稿怎样得到一份 PR

1. 从站点、投稿会话和 `submissionId` 派生固定的投稿分支名，用路径、基准和内容计算请求摘要。先查该分支对应的所有状态的 PR。摘要匹配则返回已有结果，已合并或关闭的 PR 也算完成。同一编号带来不同稿件返回 `409`。
2. 如果分支上已有本稿件的提交，继续创建 PR。首次写入时先核对基准文件，再比较目标分支最新的文件 blob。其他文件变更可正常投稿。同一文件已更新时，首版保守返回 `409 stale_source` 并附最新版本，浏览器保留草稿供读者对照。两个独立 PR 之后的合并冲突由 GitHub 正常审阅。
3. 从目标分支的已核对提交创建或找回投稿分支。用 `createCommitOnBranch` 的 `expectedHeadOid` 保护**投稿分支**的并发写入，只提交目标 Markdown 文件。将请求摘要记入 commit 消息和 PR 说明，便于跨进程重试。并发失败时重新读取分支，摘要匹配即可接续。
4. 向站长配置的目标分支创建 PR。在 GitHub 已经建好 PR 但 HTTP 回包丢失时，用同一投稿分支取回既有 PR。认证失败、限频和暂时性服务错误分别反馈到原页，保留草稿。站点的发布流程由维护者合并触发。[GitHub 提交接口](https://docs.github.com/en/graphql/reference/commits#createcommitonbranch) · [GitHub PR 接口](https://docs.github.com/en/rest/pulls/pulls#create-a-pull-request)
