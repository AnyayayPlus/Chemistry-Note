# 技术选型与验证记录

## 首版实现基线

2026-11-28 核对。表中的版本是开始实施时可复现的基线。宿主兼容范围以打包产物的实际安装测试为准。

| 用途 | 选型 | 选它解决的具体问题 |
| --- | --- | --- |
| 原位富文本 | Milkdown Kit 7.23.0，MIT | 全文共用一个 ProseMirror 文档，直接复用 CommonMark、GFM 表格、历史和格式命令。parse5 提供 HTML 表格的单元格位置与跨度。化学公式优先复用宿主已有的 MathJax 结果，新增预览由 KaTeX 渲染。[Milkdown](https://milkdown.dev/) · [7.23.0 发布](https://github.com/Milkdown/milkdown/releases/tag/v7.23.0) |
| 原文与左右分屏 | CodeMirror 6，基线 `@codemirror/view` 6.44.1 | 两种视图共用编辑状态、选区和撤销记录。使用 `@codemirror/lang-markdown` 处理源码语法。[CodeMirror 参考手册](https://codemirror.net/docs/ref/) · [发布版本](https://www.npmjs.com/package/@codemirror/view/v/6.44.1) |
| 源码定位与预览 | `mdast-util-from-markdown` 2.1.0 和 `markdown-it` 14.3.3 | 前者提供块和文字的源码偏移，后者渲染 Markdown。混排文字携带源位置，避免重复文字定位到另一处。各自作为直接依赖。默认禁止执行原始 HTML 与 Vue 模板，支持的 HTML 元素按允许的标签、属性和 URL 渲染。编辑预览可扩展，最终页面使用宿主的 VitePress 构建。[mdast](https://github.com/syntax-tree/mdast-util-from-markdown) · [markdown-it](https://github.com/markdown-it/markdown-it) |
| GitHub 投稿 | Octokit 5.0.5，MIT，仓库约 7.9k ★ | 使用官方 SDK 获取短期安装令牌，复用 GitHub 的 ref、commit 与 PR 接口。App 只安装在选定内容仓库，申请 Contents 和 Pull requests 的读写权限。首版用投稿分支、提交摘要和 PR 恢复已完成的步骤。[Octokit](https://github.com/octokit/octokit.js) · [GitHub Git 对象](https://docs.github.com/en/graphql/reference/git) |
| 构建与验证 | TypeScript ESM、Vue 3、pnpm、Vite、`vue-tsc`、Node 测试运行器和 Playwright | Vue 与 VitePress 作为宿主依赖。Vite 库模式构建 Vue 入口，服务端及构建入口按 Node ESM 输出。Node 测源码和投稿状态，Playwright 从真实页面操作编辑器。用 `pnpm pack` 的 tarball 验证子路径导出、类型和按需加载。[Vite 库模式](https://vite.dev/guide/build#library-mode) · [VitePress SSR](https://vitepress.dev/guide/ssr-compat) |

开发环境以 Node 24 为基线。第一组宿主是默认主题 VitePress 1.6.4，第二组是 Chemistry-Note 锁定的 2.0.0-alpha.21。化学公式、已有图片的暗色标记和站点专用组件放在试点适配中。[试点依赖](https://github.com/AnyayayPlus/Chemistry-Note/blob/23a5ad5e5e201a63f3c468b197fd66c345a5c17b/package.json) · [试点站点配置](https://github.com/AnyayayPlus/Chemistry-Note/blob/23a5ad5e5e201a63f3c468b197fd66c345a5c17b/.vitepress/config.mts)

## 源码保真的实测依据

样本取自 Chemistry-Note 提交 `23a5ad5`。90 个受 Git 跟踪的 Markdown 文件中，67 个出现了化学命令 `\ce{`，45 个出现了原生 `<img>`。最大文件为 43,657 字节。首版采用单篇文本草稿保存在浏览器本地，文件上传单独安排。[样本提交](https://github.com/AnyayayPlus/Chemistry-Note/commit/23a5ad5e5e201a63f3c468b197fd66c345a5c17b)

| 已做的实验 | 结果 | 对实现的约束 |
| --- | --- | --- |
| 本地 Chrome 中，用默认 Milkdown Crepe 和 Vditor 打开《电解池》《构造原理、泡利原理、洪特规则》和《贡献指南》，各改一处文字后导出整篇正文。 | 两款编辑器都在 3/3 篇产生无关差异。Crepe 把图片 alt 中的 `&keep-color` 写成 `1.00`，Vditor 给提示框加了英文标题。 | 草稿以原文为准，打开、关闭和切换视图都应产生零差异。 |
| 在相同浏览器和文章中，只把点击的块交给富文本编辑器，再替换源文件中对应的范围。 | 两款编辑器各 3/3 篇最终结果与预期逐字节相等，样本为两个标题和一个含粗体的段落。 | 普通标题与段落可作为第一个真实投稿的范围，表格和复杂混排另验。 |
| 用表中版本的 mdast 和 markdown-it 对齐这三个块，另加入一份带 BOM、CRLF 与非 BMP 汉字的样本。 | 四组都能唯一匹配预览块，按原文范围替换后 UTF-8 字节与预期相同。`&amp;` 的显示值与原文长度不同。 | 普通文字可直接映射，实体、转义和未识别扩展需要保留原文或使用明确的偏移映射。 |

第四组可用含 YAML 文件头的 CRLF 文档复现。在带 UTF-8 BOM 的文件中加入段落 `读者𠮷修改这一句，再读**下一句**。`，将「这一句」替换为「这句话」，检查 BOM、换行以及粗体标记的原始字节。这个用例验证源码坐标，浏览器的中文输入法另在 M2 验收。

## 两个设计取舍

**已选 Milkdown。** Vditor 的三种模式开箱可用，Decap CMS 有完整的 GitHub Open Authoring 流程。这个库要在宿主页面内处理带公式和 Vue 组件的正文，并允许读者用站点身份来稿。Milkdown 可扩展的编辑节点和独立的 GitHub App 投稿接口能分别满足这两点。[Vditor 4.0.1](https://github.com/Vanessa219/vditor/releases/tag/v4.0.1) · [Decap 公开投稿](https://decapcms.org/docs/open-authoring/)

**独立仓库，原站编辑。** 插件需要独立发版和跨宿主测试。Chemistry-Note 从仓库根目录扫描 Markdown，其规则会把普通的 `playground/docs/editing.md` 识别为文章。独立库用本地 tarball 联调，读者则留在熟悉的原文、主题与公式上下文中。只有多个宿主需要统一编辑后台或只能放置跳转链接时，才有另建托管编辑站的实际收益。[试点内容扫描逻辑](https://github.com/AnyayayPlus/Chemistry-Note/blob/23a5ad5e5e201a63f3c468b197fd66c345a5c17b/.vitepress/siteData/content.ts)
