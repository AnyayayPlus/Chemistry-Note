# vitepress-inline-editor

读者在 VitePress 文章里点「编辑此页」，选中正文就能用 Milkdown 修改。点「查看改动」核对差异，再点「提交修改」，由站点的 GitHub App 开分支和 Pull Request（PR）。读者可以没有 GitHub 账号。维护者沿用内容仓库的审阅和发布流程。

## 本地体验

在本仓库使用 Node 24 和 pnpm 12.14.0。

```sh
pnpm install --frozen-lockfile
pnpm dev --port 5173
```

打开示例文章，把「请在这里修正错宇。」中的「宇」改成「字」。可以直接刷新并重新打开编辑器，或在「可视化」「源码」「分屏预览」间切换。提交后点「查看本地审阅稿」，可以看到该次真实 Git 提交的差异。示例使用独立的裸仓库，保存在 `playground/.vitepress/cache/inline-editor/`。[打开示例文章](http://127.0.0.1:5173/guide)

| 读者需要做什么 | 首版支持 |
| --- | --- |
| 纠正正文或标题 | 默认原位编辑。普通块使用 Milkdown，可加粗、斜体、撤销。混排块仅开放有准确源码位置的文字。 |
| 编辑 Markdown | 源码和分屏共用 CodeMirror，桌面左右并排，窄屏上下排列。草稿存放在当前浏览器。 |
| 查看图片、徽章与化学公式 | 优先复用已构建页面的图片地址和 MathJax 输出。已有资源跟随原文保留。可在源码中添加 HTTPS 图片引用。文件上传和存储留待后续版本。 |
| 修改含扩展语法的文章 | YAML 文件头、组件、公式和代码等受保护。预览支持普通 Markdown、提示引用、徽章、图片和公式，未知 HTML 或 Vue 片段显示源码。站点自定义插件的最终效果以宿主构建为准。 |

## 接入另一个站点

先在插件仓库构建并打包，再在目标站点安装同一个文件。

```sh
# 插件仓库
pnpm run build
pnpm pack --pack-destination /tmp

# 目标站点仓库
pnpm add /tmp/vitepress-inline-editor-0.1.0-dev.2.tgz
```

站长选择允许编辑的 Markdown 路径。下面假设 `.vitepress/config.mts` 位于内容仓库根目录下的 `.vitepress/`，文章放在 `docs/`。路径规则相对于 Git 仓库根目录。插件负责处理 `srcDir`、路由重写和部署前缀。

```ts
import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vitepress'
import { withInlineEditor } from 'vitepress-inline-editor/vitepress'

export default withInlineEditor(defineConfig({ srcDir: 'docs' }), {
  repoRoot: fileURLToPath(new URL('../', import.meta.url)),
  include: ['docs/guide/**/*.md'],
  apiBase: '/api/editor/',
})
```

构建时默认读取 Git HEAD。没有 `.git` 的构建环境可用 `revision` 传入内容仓库的完整提交 SHA。页面的 `editLink: false` 可单独关闭入口。

默认主题可以在 `.vitepress/theme/index.ts` 挂入编辑按钮。已有自定义布局时，把 `<InlineEditor />` 加到现有 `doc-before` 插槽，保留同一插槽中的其他组件。自定义正文容器可通过 `contentSelector` 指定。

```ts
import { h } from 'vue'
import DefaultTheme from 'vitepress/theme'
import { InlineEditor } from 'vitepress-inline-editor/vue'
import 'vitepress-inline-editor/style.css'

export default {
  extends: DefaultTheme,
  Layout: () => h(DefaultTheme.Layout, null, { 'doc-before': () => h(InlineEditor) }),
}
```

## 用 GitHub App 开 PR

在管理机运行下面的命令，将 `OWNER/REPO` 换成内容仓库。在同一浏览器用有权注册和安装 App 的维护者账号登录 GitHub，再打开命令打印的本机链接。组织仓库会进入组织的 App 注册页。确认注册后，安装时选 **Only select repositories**，勾选该仓库。注册清单只申请 **Contents** 和 **Pull requests** 读写权限，事件订阅为空。[GitHub App 注册清单](https://docs.github.com/en/apps/sharing-github-apps/registering-a-github-app-from-a-manifest)

```sh
pnpm exec vitepress-editor-setup OWNER/REPO
```

GitHub 回调后，命令把 App 私钥、App ID 和随机会话密钥保存在打印出的 `github.env`，文件权限为 `0600`。默认目录为 `~/.config/vitepress-inline-editor/OWNER/REPO/`，也支持 `XDG_CONFIG_HOME`。重新运行会给出已有 App 的安装链接。把这份文件作为服务端密钥配置。下面的命令适用于默认分支为 `main`、编辑范围为 `docs/guide/` 的站点。

```sh
SITE_ORIGIN=https://notes.example.org CONTENT_BRANCH=main EDITOR_PATHS='["docs/guide/**/*.md"]' \
  pnpm exec vitepress-editor-api --env-file "$HOME/.config/vitepress-inline-editor/OWNER/REPO/github.env"
```

服务通过 App 身份向 GitHub 查询目标仓库的安装 ID。使用已有 App 时，也可以通过下表手动配置。纯静态站点可继续使用原来的静态托管，由反向代理把同源 `/api/editor/` 转发到这个服务。[GitHub App 安装身份](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/authenticating-as-a-github-app-installation)

| 服务端环境变量 | 设置 |
| --- | --- |
| `CONTENT_REPOSITORY`、`CONTENT_BRANCH` | 目标仓库 `owner/repo` 和分支，分支默认 `main`。Chemistry-Note 使用 `master`。 |
| `EDITOR_PATHS` | JSON 数组，例如 `["docs/guide/**/*.md"]`。与站点构建的 `include` 一致。示例站默认仅开放 `playground/docs/guide.md`。 |
| `SITE_ORIGIN` | 读者打开的站点来源，例如 `https://notes.example.org`。 |
| `EDITOR_SESSION_SECRET` | 服务端持久保存的随机密钥，至少 32 个字符，可用 `openssl rand -hex 32` 生成。多实例共用同一密钥。 |
| `GITHUB_APP_ID`、`GITHUB_INSTALLATION_ID` | App ID 必填。安装 ID 默认自动查询，也可以指定。 |
| `GITHUB_APP_PRIVATE_KEY_FILE` | 服务可读的 PEM 文件路径。也可用 `GITHUB_APP_PRIVATE_KEY` 传入完整多行 PEM。 |

在已安装插件的站点项目中，用上述环境启动服务。

```sh
pnpm exec vitepress-editor-api
```

默认监听 `127.0.0.1:8787`，通过 `HOST` 和 `PORT` 配置。也可把 `createEditorHandler(options)` 接到现有 Node 服务或函数。它接受标准 `Request` 并返回 `Response`，`authorize(request)` 可对接站点已有登录体系。公开笔记使用签名投稿会话，服务端独立检查文件范围、版本、受保护语法和 256 KiB 的单篇上限。投稿分支和 PR 位于配置的仓库，合并由维护者决定。

同一投稿会话内，网络重试会找回已经创建的稿件。同一篇文章被更新时，编辑器保留本地草稿。互不重叠且能干净应用的改动可移到新版，有重叠则由读者对照后再提交。

### 投稿署名

为命令行服务同时配置 `EDITOR_CONTRIBUTIONS_URL` 和 `EDITOR_CONTRIBUTIONS_TOKEN` 后，读者在「查看改动」中填写用户名、邮箱。下次投稿会从同一站点的浏览器本地存储预填。服务端在开 PR 前，以 Bearer 凭据向该私有地址 POST 仓库、目标分支、投稿分支、源文件路径及署名。接收端按投稿分支幂等保存，成功后返回 2xx 和 `{"ok":true}`。GitHub 上的提交和 PR 只包含稿件数据。公开署名由接收端核实合并后生成。

自行集成时可传入 `createEditorHandler({ ..., recordContribution, resolveContributor })`。`recordContribution(entry)` 负责持久化，失败会阻止开 PR。`resolveContributor(request, claimed)` 是可选的服务端账号接入口，可从已认证的会话返回用户名、邮箱及稳定的 `accountId`。未接账号系统时使用读者自填的署名。宿主可通过 `<InlineEditor require-contributor />` 要求后端支持署名，通过自己的设置项决定是否挂载编辑器。

## 验证

```sh
pnpm test
pnpm exec playwright install chromium
pnpm run test:browser
pnpm run playground:build
```

本机已有 Chrome 时，可用 `PLAYWRIGHT_CHANNEL=chrome pnpm run test:browser`。实际安装检查覆盖 VitePress 1.6.4 默认主题与 Chemistry-Note 2.0.0-alpha.21 的隔离副本。GitHub 适配器的自动化测试使用 Octokit 和本地 HTTP 测试替身，覆盖安装令牌、投稿分支、单文件提交和 PR 请求。

在 Chemistry-Note 的本机试点页，用 Milkdown 将《电解池》里的 `PH 的变化` 改为 `pH 的变化`，点击「提交修改」后，页面显示了站点 GitHub App 创建的 PR 链接。从 GitHub 读回整篇 5,752 字节的 Markdown，与基准逐字节比较，只有这一个字母发生了变化。[查看试点 PR #205](https://github.com/AnyayayPlus/Chemistry-Note/pull/205)

架构、开源项目比较和分阶段验收记录分别保存在以下文档。

- [架构与接口](docs/architecture.md)
- [技术选型与验证记录](docs/technology.md)
- [实施计划与验收](docs/implementation-plan.md)

### 接入站点账号

站点要求登录后投稿时设置 `EDITOR_REQUIRE_ACCOUNT=true`，缺少身份服务时启动会报错。设置 `EDITOR_ACCOUNT_URL` 指向与贡献记录服务同源的私有身份接口。用 `EDITOR_ACCOUNT_COOKIE` 指定站点的读者会话 Cookie 名。命令行适配器仅转发该 Cookie，以服务凭据调用该接口。200 返回服务端确认的 `accountId`、`name`、`email`，可带同源的 `profileUrl`、`submissionsUrl`。401 表示需要登录，428 表示需要设置公开署名。自定义后端可直接提供 `submissionAccount(request)` 和 `recordContribution(entry)`。

宿主向 `InlineEditor` 传入 `account`，实现 `signIn(returnTo)`、`current()` 和 `setName(name)`。只有实际提交才会引导登录。重定向之前保留草稿和提交编号，返回文章后恢复差异供读者确认。读取原文和预览可以匿名进行。其他接入方式仍可使用原有的署名表单。
